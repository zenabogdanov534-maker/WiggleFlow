# Native <-> JavaScript bridge methods must remain visible when minification is enabled.
-keepclassmembers class * { @android.webkit.JavascriptInterface <methods>; }
