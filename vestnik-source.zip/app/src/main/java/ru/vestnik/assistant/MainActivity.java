package ru.vestnik.assistant;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.graphics.Color;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.view.WindowManager;
import android.view.WindowInsets;
import android.graphics.Insets;

import org.json.JSONObject;
import org.json.JSONArray;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {
    private WebView web;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ConcurrentHashMap<String, Future<?>> requests = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, HttpURLConnection> connections = new ConcurrentHashMap<>();
    private SharedPreferences prefs;
    private static final String KEY_ALIAS = "vestnik_secret_aes_v1";
    private static final String DEFAULT_PROMPT = "Ты — Вестник, умный и внимательный ИИ-помощник. Отвечай на языке пользователя. Давай точные, проверяемые ответы, объясняй сложное простыми словами. Когда не уверен, честно об этом говори. Поддерживай контекст диалога, помогай с программированием, учёбой, творчеством и планированием. Структурируй большие ответы и избегай выдуманных фактов.";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if (Build.VERSION.SDK_INT >= 29) getWindow().setNavigationBarContrastEnforced(false);
        prefs = getSharedPreferences("vestnik_data", Context.MODE_PRIVATE);
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(11, 15, 25));
        // Android 15+ renders apps edge-to-edge by default for modern target SDKs.
        if (Build.VERSION.SDK_INT >= 35) {
            getWindow().setDecorFitsSystemWindows(false);
            web.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets safe = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
                return insets;
            });
        }
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        web.getSettings().setSupportMultipleWindows(false);
        web.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebContentsDebuggingEnabled(false);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                return !url.startsWith("file:///android_asset/");
            }
        });
        web.addJavascriptInterface(new NativeBridge(), "VestnikNative");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private String configuredUrl(String provider, String custom) throws Exception {
        if ("openrouter".equals(provider)) return "https://openrouter.ai/api/v1/chat/completions";
        if ("openai".equals(provider)) return "https://api.openai.com/v1/chat/completions";
        String u = custom.trim();
        if (u.isEmpty()) throw new IllegalArgumentException("Укажите адрес вашего сервера в настройках.");
        if (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        if (!u.endsWith("/chat/completions")) {
            if (u.endsWith("/v1")) u += "/chat/completions";
            else u += "/v1/chat/completions";
        }
        URL url = new URL(u);
        String scheme = url.getProtocol().toLowerCase();
        if (!"https".equals(scheme)) {
            String host = url.getHost().toLowerCase();
            boolean local = host.equals("localhost") || host.equals("127.0.0.1")
                || host.endsWith(".local") || host.startsWith("192.168.") || host.startsWith("10.")
                || host.matches("172\\.(1[6-9]|2[0-9]|3[01])\\..*");
            if (!"http".equals(scheme) || !local)
                throw new IllegalArgumentException("Для внешних серверов требуется HTTPS; HTTP разрешён только для локальной сети.");
        }
        if (url.getUserInfo() != null) throw new IllegalArgumentException("Адрес не должен содержать логин и пароль.");
        return u;
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) return (SecretKey) ks.getKey(KEY_ALIAS, null);
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).build());
        return generator.generateKey();
    }

    private void saveApiKey(String raw) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
        byte[] encrypted = cipher.doFinal(raw.getBytes(StandardCharsets.UTF_8));
        String value = Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP) + ":" + Base64.encodeToString(encrypted, Base64.NO_WRAP);
        prefs.edit().putString("secret", value).apply();
    }
    private String readApiKey() throws Exception {
        String saved = prefs.getString("secret", "");
        if (saved.isEmpty()) return "";
        String[] parts = saved.split(":", 2);
        if (parts.length != 2) throw new IllegalStateException("Не удалось прочесть сохранённый ключ. Сохраните его заново.");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, Base64.decode(parts[0], Base64.DEFAULT)));
        return new String(cipher.doFinal(Base64.decode(parts[1], Base64.DEFAULT)), StandardCharsets.UTF_8);
    }
    private static String readStream(InputStream input) throws IOException {
        if (input == null) return "";
        try (InputStream s = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int count;
            while ((count = s.read(buffer)) != -1) {
                if (out.size() + count > 3_000_000) throw new IOException("Слишком большой ответ сервера.");
                out.write(buffer, 0, count);
            }
            return out.toString("UTF-8");
        }
    }

    private void reply(String id, boolean success, String value, String model) {
        JSONObject msg = new JSONObject();
        try {
            msg.put("ok", success);
            if (success) { msg.put("text", value); msg.put("model", model); }
            else msg.put("error", value);
        } catch (Exception ignored) {}
        String script = "window.Vestnik&&window.Vestnik.onAIResult(" + JSONObject.quote(id) + "," + JSONObject.quote(msg.toString()) + ");";
        main.post(() -> { if (web != null) web.evaluateJavascript(script, null); });
    }

    private void submit(String id, String json) {
        try {
            String provider = prefs.getString("provider", "openrouter");
            String model = prefs.getString("model", "openrouter/auto").trim();
            String endpoint = configuredUrl(provider, prefs.getString("endpoint", ""));
            String key = readApiKey();
            if (key.isEmpty() && !"custom".equals(provider)) throw new IllegalArgumentException("Добавьте API-ключ в настройках.");
            if (model.isEmpty()) throw new IllegalArgumentException("Укажите название ИИ-модели.");
            JSONObject incoming = new JSONObject(json);
            JSONArray history = incoming.optJSONArray("messages");
            if (history == null || history.length() < 1 || history.length() > 80) throw new IllegalArgumentException("Ошибка истории чата.");
            JSONArray messages = new JSONArray();
            messages.put(new JSONObject().put("role", "system").put("content", prefs.getString("prompt", DEFAULT_PROMPT)));
            for (int i=0; i<history.length(); i++) {
                JSONObject msg = history.getJSONObject(i);
                String role = msg.optString("role", "");
                String content = msg.optString("content", "");
                if (!(role.equals("user") || role.equals("assistant"))) continue;
                if (content.length() > 15000) content = content.substring(0, 15000);
                if (!content.isEmpty()) messages.put(new JSONObject().put("role", role).put("content", content));
            }
            JSONObject body = new JSONObject()
                .put("model", model)
                .put("messages", messages)
                .put("stream", false);
            body.put("openai".equals(provider) ? "max_completion_tokens" : "max_tokens",
                prefs.getInt("max_tokens", 2048));
            if ("openrouter".equals(provider) && "openrouter/auto".equals(model)) {
                body.put("plugins", new JSONArray().put(new JSONObject().put("id", "auto-router")
                    .put("cost_tier", prefs.getString("quality", "high"))));
            }
            HttpURLConnection c = (HttpURLConnection) new URL(endpoint).openConnection();
            connections.put(id, c);
            c.setRequestMethod("POST");
            c.setConnectTimeout(20000);
            c.setReadTimeout(120000);
            c.setDoOutput(true);
            c.setInstanceFollowRedirects(false);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setRequestProperty("Accept", "application/json");
            if (!key.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + key);
            if ("openrouter".equals(provider)) c.setRequestProperty("X-Title", "Vestnik");
            try (OutputStream output = c.getOutputStream()) { output.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
            int code = c.getResponseCode();
            String payload = readStream(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream());
            if (code < 200 || code >= 300) {
                String error = "HTTP " + code;
                try { error += ": " + new JSONObject(payload).optJSONObject("error").optString("message", "Ошибка провайдера"); }
                catch (Exception ignored) { if (!payload.isEmpty()) error += ": " + payload.substring(0, Math.min(payload.length(), 230)); }
                throw new IOException(error);
            }
            JSONObject result = new JSONObject(payload);
            JSONObject choice = result.getJSONArray("choices").getJSONObject(0);
            JSONObject answer = choice.optJSONObject("message");
            if (answer == null) throw new IOException("Сервер не вернул ответ модели.");
            String content = answer.optString("content", "");
            if (content.isEmpty()) {
                Object raw = answer.opt("content");
                if (raw instanceof JSONArray) {
                    StringBuilder combined = new StringBuilder();
                    JSONArray parts = (JSONArray) raw;
                    for (int i=0; i<parts.length(); i++) {
                        JSONObject part = parts.optJSONObject(i);
                        if (part != null) combined.append(part.optString("text", ""));
                    }
                    content = combined.toString();
                }
            }
            if (content.isEmpty()) throw new IOException("Модель вернула пустой текст. Попробуйте другую модель.");
            reply(id, true, content, result.optString("model", model));
        } catch (Exception ex) {
            reply(id, false, ex.getMessage() != null ? ex.getMessage() : "Ошибка соединения.", "");
        } finally {
            HttpURLConnection c = connections.remove(id);
            if (c != null) c.disconnect();
            requests.remove(id);
        }
    }

    public class NativeBridge {
        @JavascriptInterface public String getSettings() {
            JSONObject data = new JSONObject();
            try {
                data.put("provider", prefs.getString("provider", "openrouter"));
                data.put("model", prefs.getString("model", "openrouter/auto"));
                data.put("endpoint", prefs.getString("endpoint", ""));
                data.put("prompt", prefs.getString("prompt", DEFAULT_PROMPT));
                data.put("quality", prefs.getString("quality", "high"));
                data.put("max_tokens", prefs.getInt("max_tokens", 2048));
                data.put("hasKey", !prefs.getString("secret", "").isEmpty());
            } catch (Exception ignored) {}
            return data.toString();
        }
        @JavascriptInterface public String saveSettings(String settings) {
            try {
                JSONObject v = new JSONObject(settings);
                String provider = v.optString("provider", "openrouter");
                if (!(provider.equals("openrouter") || provider.equals("openai") || provider.equals("custom")))
                    throw new IllegalArgumentException("Неверный провайдер.");
                String model = v.optString("model", "").trim();
                if (model.length() < 1 || model.length() > 150) throw new IllegalArgumentException("Название модели не указано.");
                String endpoint = v.optString("endpoint", "").trim();
                configuredUrl(provider, endpoint);
                String prompt = v.optString("prompt", DEFAULT_PROMPT);
                if (prompt.length() > 7000) throw new IllegalArgumentException("Слишком длинная инструкция.");
                int tokens = Math.max(256, Math.min(8192, v.optInt("max_tokens", 2048)));
                String quality = v.optString("quality", "high");
                if (!(quality.equals("low") || quality.equals("medium") || quality.equals("high") || quality.equals("xhigh") || quality.equals("max"))) quality = "high";
                String newKey = v.optString("apiKey", "").trim();
                if (!newKey.isEmpty()) saveApiKey(newKey);
                if (v.optBoolean("clearKey", false)) prefs.edit().remove("secret").apply();
                prefs.edit().putString("provider", provider).putString("model", model)
                    .putString("endpoint", endpoint).putString("prompt", prompt)
                    .putString("quality", quality).putInt("max_tokens", tokens).apply();
                return new JSONObject().put("ok", true).toString();
            } catch (Exception ex) {
                try { return new JSONObject().put("ok", false).put("error", ex.getMessage()).toString(); }
                catch (Exception ignored) { return "{\"ok\":false}"; }
            }
        }
        @JavascriptInterface public String loadChats() { return prefs.getString("chats", "[]"); }
        @JavascriptInterface public void saveChats(String chats) {
            if (chats != null && chats.length() <= 2_000_000) prefs.edit().putString("chats", chats).apply();
        }
        @JavascriptInterface public void askAI(String id, String json) {
            if (id == null || id.length() > 100 || json == null || json.length() > 600000) return;
            Future<?> f = executor.submit(() -> submit(id, json));
            requests.put(id, f);
        }
        @JavascriptInterface public void cancelAI(String id) {
            Future<?> f = requests.remove(id);
            if (f != null) f.cancel(true);
            HttpURLConnection c = connections.remove(id);
            if (c != null) c.disconnect();
        }
        @JavascriptInterface public void copyText(String value) {
            main.post(() -> ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE))
                .setPrimaryClip(ClipData.newPlainText("Вестник", value)));
        }
    }
    @Override public void onBackPressed() {
        if (web != null) web.evaluateJavascript("window.Vestnik&&window.Vestnik.back()", result -> {
            if (!"true".equals(result)) finish();
        });
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        for (HttpURLConnection c : connections.values()) c.disconnect();
        executor.shutdownNow();
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }
}
