(() => {
  'use strict';
  const N = typeof window.VestnikNative !== 'undefined' ? window.VestnikNative : null;
  const $ = id => document.getElementById(id);
  const defaultPrompt = 'Ты — Вестник, универсальный и компетентный ИИ-помощник. Отвечай на языке пользователя, по существу, подробно когда это нужно. Помогай с техническими и творческими задачами без навязанных лимитов стиля или длины. Когда не уверен, честно сообщай, не выдумывай факты.';
  const defaults = {provider:'openrouter',model:'openrouter/free',endpoint:'',prompt:defaultPrompt,quality:'high',max_tokens:0,hasKey:false,hasMediaKey:false,image_model:'',video_model:''};
  let settings = {...defaults};
  let chats = [];
  let mediaHistory = [];
  let mode = 'chat';
  let mediaPending = null;
  let activeId = null;
  let pending = null;
  let toastTimer = null;
  const id = () => Date.now().toString(36) + '-' + Math.random().toString(36).slice(2,8);

  function init() {
    try {
      if (N) {
        settings = {...defaults,...JSON.parse(N.getSettings())};
        chats = JSON.parse(N.loadChats() || '[]');
        mediaHistory = JSON.parse(N.loadGallery() || '[]');
      } else {
        settings = {...defaults,...JSON.parse(localStorage.getItem('vestnik_settings_preview') || '{}'),hasKey:false};
        chats = JSON.parse(localStorage.getItem('vestnik_chats_preview') || '[]');
        mediaHistory = JSON.parse(localStorage.getItem('vestnik_media_preview') || '[]');
      }
      if (!Array.isArray(chats)) chats = [];
      chats = chats.filter(c => c && typeof c.id === 'string' && Array.isArray(c.messages)).slice(0,60);
      chats.forEach(c => c.messages.forEach(m => {
        if (m.loading) {delete m.loading; m.failed=true; m.content='⚠ Соединение было прервано.';}
      }));
    } catch(e) { chats = []; }
    if (!Array.isArray(mediaHistory)) mediaHistory=[];
    setActive(null);
    wireEvents();
    syncSettings();
    refreshChats();
    render();
    showMode('chat');
  }
  function persist() {
    const serialized = JSON.stringify(chats);
    try {
      if (N) N.saveChats(serialized);
      else localStorage.setItem('vestnik_chats_preview',serialized);
    } catch(e) { toast('Не получилось сохранить историю.'); }
  }
  function configured() { return Boolean(settings.model && (settings.provider === 'custom' ? settings.endpoint : settings.hasKey)); }
  function syncSettings() {
    $('statusDot').classList.toggle('ready',configured());
    $('statusText').textContent = configured() ? 'Модель подключена' : 'Модель не настроена';
    $('headerModel').textContent = configured() ? settings.model : 'Умный ИИ-помощник';
    $('composerHint').innerHTML = configured() ? '<span>✦</span> Готов помочь' : '<span>✦</span> Подключите модель в настройках';
  }
  function setActive(nextId) { activeId = nextId; }
  function activeChat() { return chats.find(c => c.id === activeId) || null; }
  function createChat() {
    const c = {id:id(), title:'Новый диалог', created:Date.now(), updated:Date.now(),messages:[]};
    chats.unshift(c); activeId = c.id;
    persist(); refreshChats(); render(); closeSidebar();
    $('messageInput').focus();
    return c;
  }
  function refreshChats() {
    $('chatCount').textContent = String(chats.length);
    const target = $('chatList');
    if (!chats.length) {target.innerHTML='<div class="side-empty">Диалогов пока нет</div>'; return;}
    target.innerHTML = chats.map(c => `<div class="chat-item ${c.id===activeId?'active':''}" data-chat="${escapeAttr(c.id)}" role="button" tabindex="0"><span class="chat-item-icon">▤</span><span class="chat-item-name">${escapeHTML(c.title)}</span><button class="chat-menu" data-menu="${escapeAttr(c.id)}" aria-label="Действия с диалогом">•••</button></div>`).join('');
    target.querySelectorAll('[data-chat]').forEach(item => {
      item.addEventListener('click', e => {
        if (e.target.closest('[data-menu]')) return;
        setActive(item.dataset.chat); closeSidebar(); refreshChats(); render();
      });
      item.addEventListener('keydown',e => {if(e.key==='Enter') item.click();});
    });
    target.querySelectorAll('[data-menu]').forEach(button => button.addEventListener('click', e => {
      e.stopPropagation();
      const c = chats.find(x => x.id === button.dataset.menu);
      if (!c) return;
      const result = window.prompt('Введите новое название диалога. Чтобы удалить, введите /удалить',c.title);
      if (result === null) return;
      if (result.trim() === '/удалить') {
        if (!confirm('Удалить диалог? Это действие нельзя отменить.')) return;
        chats = chats.filter(x => x.id !== c.id);
        if (activeId === c.id) activeId = null;
      } else if (result.trim()) c.title = result.trim().slice(0,70);
      persist(); refreshChats(); render();
    }));
  }
  function escapeHTML(input) {return String(input ?? '').replace(/[&<>"']/g,ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));}
  function escapeAttr(input) {return escapeHTML(input);}
  function inlineMarkdown(text) {
    return escapeHTML(text)
      .replace(/`([^`\n]+)`/g, '<code>$1</code>')
      .replace(/\*\*([^*\n]+)\*\*/g,'<strong>$1</strong>')
      .replace(/(^|[^*])\*([^*\n]+)\*/g,'$1<em>$2</em>');
  }
  function formatMarkdown(raw) {
    const codeBlocks = [];
    let text = String(raw ?? '').replace(/```[^\n]*\n([\s\S]*?)```/g, (_,code) => {
      const idx = codeBlocks.push('<pre><code>'+escapeHTML(code.trim())+'</code></pre>') - 1;
      return '\n\nVESTNIK_CODE_BLOCK_' + idx + '\n\n';
    });
    const blocks = text.split(/\n{2,}/).filter(x => x.trim()).map(block => {
      const b = block.trim();
      const marker = /^VESTNIK_CODE_BLOCK_(\d+)$/.exec(b);
      if (marker) return codeBlocks[+marker[1]] || '';
      if (/^#{1,3} /m.test(b) && b.indexOf('\n')===-1) return '<h3>'+inlineMarkdown(b.replace(/^#{1,3} /,''))+'</h3>';
      if (/^(?:[-*] |\d+[.)] )/m.test(b)) {
        const lines=b.split('\n');
        const isNumber=/^\d+[.)] /.test(lines[0]);
        const tag=isNumber?'ol':'ul';
        return `<${tag}>`+lines.map(line=>'<li>'+inlineMarkdown(line.replace(/^([-*] |\d+[.)] )/,''))+'</li>').join('')+`</${tag}>`;
      }
      if (b.startsWith('> ')) return '<blockquote>'+inlineMarkdown(b.slice(2)).replace(/\n/g,'<br>')+'</blockquote>';
      return '<p>'+inlineMarkdown(b).replace(/\n/g,'<br>')+'</p>';
    });
    return blocks.join('');
  }
  function render() {
    const c = activeChat();
    $('welcome').classList.toggle('hidden', mode!=='chat' || Boolean(c && c.messages.length));
    $('messages').classList.toggle('hidden', mode!=='chat' || !c || !c.messages.length);
    if (!c || !c.messages.length) { $('messages').innerHTML = ''; updateSend(); return; }
    $('messages').innerHTML = c.messages.map((msg, index) => {
      const user=msg.role==='user';
      const name=user?'Вы':'Вестник';
      const content=msg.loading ? '<div class="typing"><i></i><i></i><i></i></div>' : formatMarkdown(msg.content);
      return `<article class="message ${user?'user':'assistant'}"><div class="avatar ${user?'user':'assistant'}">${user?'◉':'В'}</div><div class="message-body"><div class="message-meta">${name}</div><div class="message-content">${content}</div>${msg.loading?'':`<div class="message-actions"><button data-copy="${index}">Копировать</button></div>`}</div></article>`;
    }).join('');
    $('messages').querySelectorAll('[data-copy]').forEach(b => b.addEventListener('click',() => {
      const msg=c.messages[Number(b.dataset.copy)];
      if (msg) copy(msg.content);
    }));
    requestAnimationFrame(() => { const x=$('contentArea'); x.scrollTop=x.scrollHeight; });
    updateSend();
  }
  function toast(message) {
    clearTimeout(toastTimer);
    $('toast').textContent=message;
    $('toast').classList.remove('hidden');
    toastTimer=setTimeout(()=>$('toast').classList.add('hidden'),3800);
  }
  function copy(s) {
    if (N) { N.copyText(s); toast('Скопировано'); }
    else if (navigator.clipboard) navigator.clipboard.writeText(s).then(()=>toast('Скопировано'),()=>toast('Не удалось скопировать'));
    else toast('Буфер обмена недоступен');
  }
  function updateSend() {
    const value=$('messageInput').value.trim();
    $('sendButton').disabled = mode==='chat' ? (!pending && !value) : (!mediaPending && !value);
    $('sendButton').title=(pending||mediaPending)?'Остановить запрос':(mode==='chat'?'Отправить сообщение':'Начать генерацию');
    $('sendButton').innerHTML=(pending||mediaPending)?'<span style="font-size:20px;line-height:1">■</span>':'<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m4 12 16-8-4 16-4-7-8-1Z"/><path d="m12 13 8-9"/></svg>';
    $('charCount').textContent = $('messageInput').value.length>400 ? String($('messageInput').value.length) : '';
  }
  function updateInputHeight() {
    const el=$('messageInput'); el.style.height='auto';
    el.style.height=Math.min(el.scrollHeight,170)+'px';
    updateSend();
  }
  function sendText(text) {
    const query=String(text).trim();
    if (!query || pending) return;
    if (query.length>50000) {toast('Одно сообщение не должно превышать 50 000 символов.');return;}
    if (!configured()) {openSettings();toast('Сначала подключите ИИ-модель и сохраните ключ.');return;}
    if (!N) {toast('Это браузерная демонстрация. Настоящий ИИ работает в Android-приложении.');return;}
    const c=activeChat() || createChat();
    if (c.messages.length===0) c.title = query.length>38 ? query.slice(0,38)+'…' : query;
    c.messages.push({role:'user',content:query,created:Date.now()});
    c.messages.push({role:'assistant',content:'',loading:true,created:Date.now()});
    c.updated=Date.now();
    const messages=c.messages.filter(m=>!m.loading&&!m.failed).slice(-100).map(m=>({role:m.role,content:m.content}));
    $('messageInput').value='';updateInputHeight();
    pending={requestId:id(),chatId:c.id,test:false};
    persist();refreshChats();render();
    try { N.askAI(pending.requestId,JSON.stringify({messages})); }
    catch(e){ onAIResult(pending.requestId,JSON.stringify({ok:false,error:'Не удалось отправить запрос: '+e.message})); }
  }
  function onAIResult(requestId,resultJson) {
    if (!pending || pending.requestId!==requestId) return;
    const job=pending;pending=null;
    let result;
    try{result=JSON.parse(resultJson);}catch(e){result={ok:false,error:'Ошибка чтения ответа.'};}
    if (job.test) {
      if(result.ok) toast('Соединение работает! Ответ модели: '+String(result.text).slice(0,80));
      else toast('Проверка: '+String(result.error).slice(0,200));
      updateSend();return;
    }
    const c=chats.find(x=>x.id===job.chatId);
    if (c) {
      const msg=c.messages.slice().reverse().find(m=>m.loading);
      if (msg){delete msg.loading;msg.content=result.ok?result.text:'⚠ '+(result.error||'Неизвестная ошибка');msg.failed=!result.ok;}
      c.updated=Date.now();
      persist();
      if (activeId===c.id) render();
      refreshChats();
    }
    if (!result.ok) toast('Не удалось получить ответ. Проверьте настройки.');
    updateSend();
  }
  function cancelPending() {
    if (!pending) return;
    const job=pending;pending=null;
    if (N) N.cancelAI(job.requestId);
    const c=chats.find(x=>x.id===job.chatId);
    if(c){const m=c.messages.slice().reverse().find(x=>x.loading);if(m){delete m.loading;m.content='Запрос остановлен.';m.failed=true;}persist();if(c.id===activeId)render();}
    toast('Запрос остановлен.');updateSend();
  }
  function openSidebar(){$('sidebar').classList.add('open');$('sidebarShade').classList.add('visible');}
  function closeSidebar(){$('sidebar').classList.remove('open');$('sidebarShade').classList.remove('visible');}
  function openSettings(){ closeSidebar(); fillSettings(); $('settingsShade').classList.remove('hidden'); }
  function closeSettings(){ $('settingsShade').classList.add('hidden'); }
  function fillSettings() {
    $('provider').value=settings.provider;
    $('model').value=settings.model;
    $('endpoint').value=settings.endpoint;
    $('apiKey').value='';$('clearKey').checked=false;
    $('quality').value=settings.quality;
    $('maxTokens').value=String(settings.max_tokens);
    $('systemPrompt').value=settings.prompt;
    $('keyStatus').textContent=settings.hasKey ? 'сохранён ✓' : 'не указан';
    $('mediaKeyStatus').textContent=settings.hasMediaKey ? 'сохранён ✓' : 'не указан';
    $('mediaKey').value='';$('clearMediaKey').checked=false;
    $('imageModel').value=settings.image_model;
    $('videoModel').value=settings.video_model;
    $('apiKey').placeholder=settings.hasKey ? 'Оставьте пустым, чтобы сохранить текущий' : 'Вставьте ключ доступа';
    refreshProviderUI();
  }
  function refreshProviderUI() {
    const p=$('provider').value;
    $('endpointGroup').classList.toggle('hidden',p!=='custom');
    $('keyGroup').querySelector('.field-hint').textContent = p==='custom'
      ? 'Необязательно для домашнего Ollama. Если сервер требует токен, вставьте его здесь.'
      : 'Ключ хранится на телефоне в зашифрованном виде. Оставьте поле пустым, чтобы сохранить текущий.';
    $('qualityGroup').classList.toggle('hidden',p!=='openrouter'||$('model').value.trim()!=='openrouter/auto');
    $('modelHint').textContent = p==='openrouter' ? 'Бесплатно: openrouter/free. Для платного маршрутизатора: openrouter/auto'
      : p==='openai' ? 'Укажите ID модели, доступной вашему ключу OpenAI'
      : 'Для Ollama введите имя скачанной модели (например, qwen3:8b)';
  }
  function collectSettings() {
    return {provider:$('provider').value,model:$('model').value.trim(),endpoint:$('endpoint').value.trim(),
      apiKey:$('apiKey').value.trim(),clearKey:$('clearKey').checked,quality:$('quality').value,
      max_tokens:Number($('maxTokens').value),prompt:$('systemPrompt').value.trim()||defaultPrompt,
      mediaKey:$('mediaKey').value.trim(),clearMediaKey:$('clearMediaKey').checked,
      image_model:$('imageModel').value.trim(),video_model:$('videoModel').value.trim()};
  }
  function saveSettings(closeOnSuccess=true) {
    const newSettings=collectSettings();
    if(!newSettings.model) {toast('Укажите ID модели.');return false;}
    if(newSettings.provider==='custom' && !/^https?:\/\//.test(newSettings.endpoint)) {toast('Укажите адрес собственного сервера с http:// или https://');return false;}
    let result={ok:true};
    try {
      if(N) result=JSON.parse(N.saveSettings(JSON.stringify(newSettings)));
      else localStorage.setItem('vestnik_settings_preview',JSON.stringify({...newSettings,apiKey:undefined,hasKey:false}));
    } catch(e){result={ok:false,error:e.message};}
    if(!result.ok) {toast('Ошибка настройки: '+(result.error||'Неизвестно'));return false;}
    settings={...settings,...newSettings,hasKey:newSettings.clearKey?false:(Boolean(newSettings.apiKey)||settings.hasKey),
      hasMediaKey:newSettings.clearMediaKey?false:(Boolean(newSettings.mediaKey)||settings.hasMediaKey)};
    delete settings.apiKey;delete settings.clearKey;delete settings.mediaKey;delete settings.clearMediaKey;
    if(!N) {settings.hasKey=false;settings.hasMediaKey=false;}
    syncSettings();
    if(mode!=='chat')showMode(mode);
    if(closeOnSuccess) {closeSettings();toast(N?'Настройки сохранены':'Интерфейс сохранён. Для ИИ нужна сборка Android.');}
    return true;
  }
  function testConnection() {
    if(pending){toast('Дождитесь предыдущего ответа.');return;}
    if(!saveSettings(false))return;
    if(!N){toast('В браузере подключение недоступно. Используйте Android-приложение.');return;}
    pending={requestId:id(),test:true};
    toast('Проверяем подключение к модели…');
    N.askAI(pending.requestId,JSON.stringify({messages:[{role:'user',content:'Ответь одним словом: работает.'}]}));
  }
  function wireEvents() {
    $('newChatBtn').addEventListener('click',()=>{showMode('chat');createChat();});
    document.querySelectorAll('[data-mode]').forEach(b=>b.addEventListener('click',()=>showMode(b.dataset.mode)));
    $('toggleSidebar').addEventListener('click',openSidebar);
    $('closeSidebar').addEventListener('click',closeSidebar);
    $('sidebarShade').addEventListener('click',closeSidebar);
    $('topSettings').addEventListener('click',openSettings);
    $('sideSettings').addEventListener('click',openSettings);
    $('closeSettings').addEventListener('click',closeSettings);
    $('settingsShade').addEventListener('click',e=>{if(e.target===$('settingsShade'))closeSettings();});
    $('provider').addEventListener('change',e=>{
      if(e.target.value==='openrouter')$('model').value='openrouter/free';
      if(e.target.value==='openai')$('model').value='gpt-4.1';
      if(e.target.value==='custom')$('model').value='qwen3:8b';
      refreshProviderUI();
    });
    $('model').addEventListener('input',refreshProviderUI);
    $('showKey').addEventListener('click',()=>{$('apiKey').type=$('apiKey').type==='password'?'text':'password';});
    $('showMediaKey').addEventListener('click',()=>{$('mediaKey').type=$('mediaKey').type==='password'?'text':'password';});
    $('saveSettings').addEventListener('click',()=>saveSettings(true));
    $('testConnection').addEventListener('click',testConnection);
    $('messageInput').addEventListener('input',updateInputHeight);
    $('messageInput').addEventListener('keydown',e=>{
      if(e.key==='Enter'&&!e.shiftKey&&window.innerWidth>760){e.preventDefault();if(mode==='chat')sendText(e.target.value);else startMedia();}
    });
    $('sendButton').addEventListener('click',()=>mode==='chat'?(pending?cancelPending():sendText($('messageInput').value)):(mediaPending?cancelMedia():startMedia()));
    $('suggestions').querySelectorAll('[data-prompt]').forEach(b=>b.addEventListener('click',()=>sendText(b.dataset.prompt)));
  }
  function back() {
    if(!$('settingsShade').classList.contains('hidden')){closeSettings();return true;}
    if($('sidebar').classList.contains('open')){closeSidebar();return true;}
    if(mode!=='chat'){showMode('chat');return true;}
    if(activeId){setActive(null);refreshChats();render();return true;}
    return false;
  }
  function showMode(next) {
    mode=['chat','image','video'].includes(next)?next:'chat';
    document.querySelectorAll('[data-mode]').forEach(b=>b.classList.toggle('selected',b.dataset.mode===mode));
    $('mediaArea').classList.toggle('hidden',mode==='chat');
    $('durationGroup').classList.toggle('hidden',mode!=='video');
    $('mediaTitle').textContent=mode==='image'?'Генерация изображений':'Генерация видео';
    $('mediaIntro').textContent=mode==='image'?'Опишите изображение: стиль, детали, свет и композицию.':'Опишите сцену и движение камеры. Видеогенерация может занимать несколько минут.';
    $('messageInput').placeholder=mode==='chat'?'Спросите Вестника о чём угодно…':mode==='image'?'Какое изображение создать?':'Какое видео создать?';
    $('composerHint').innerHTML=mode==='chat'?(configured()?'<span>✦</span> Готов помочь':'<span>✦</span> Подключите модель'):'<span>✦</span> Pollinations · '+(settings.hasMediaKey?'ключ указан':'нужен API-ключ');
    if(mode==='video' && $('mediaRatio').value==='1:1') $('mediaRatio').value='16:9';
    if(mode==='image' && $('mediaRatio').value==='16:9') $('mediaRatio').value='1:1';
    renderGallery();render();updateSend();
  }
  function saveGallery() {
    mediaHistory=mediaHistory.slice(0,40);
    const json=JSON.stringify(mediaHistory);
    if(N) N.saveGallery(json); else localStorage.setItem('vestnik_media_preview',json);
  }
  function renderGallery() {
    if(mode==='chat') return;
    const items=mediaHistory.filter(x=>x.kind===mode);
    $('mediaGallery').innerHTML=items.length?items.map(x=>`<article class="media-card ${mode==='video'?'video-thumb':''}">
      ${x.kind==='image'?`<img src="${escapeAttr(x.uri)}" alt="Созданное изображение" loading="lazy">`:'<div class="video-placeholder">▶</div>'}
      <h3>${escapeHTML(x.prompt)}</h3><small>${new Date(x.created).toLocaleString('ru-RU')}</small>
      <button data-open="${escapeAttr(x.id)}">Открыть в галерее</button></article>`).join(''):
      '<p class="gallery-empty">Ваши генерации появятся здесь.</p>';
    $('mediaGallery').querySelectorAll('[data-open]').forEach(btn=>btn.addEventListener('click',()=>{
      const item=mediaHistory.find(x=>x.id===btn.dataset.open);
      if(item && N) N.openMedia(item.uri,item.kind);
      else toast('Файл открывается в Android-приложении.');
    }));
  }
  function startMedia() {
    if(mediaPending) return;
    const prompt=$('messageInput').value.trim();
    if(!prompt) return;
    if(prompt.length>1800){toast('Для медиа максимум 1800 символов.');return;}
    if(!settings.hasMediaKey){openSettings();toast('Для изображений и видео нужен Pollinations API-ключ.');return;}
    if(!N){toast('Генерация доступна в установленном Android-приложении.');return;}
    const payload={kind:mode,prompt,ratio:$('mediaRatio').value,duration:Number($('mediaDuration').value)};
    mediaPending={id:id(),...payload};
    $('messageInput').value='';updateInputHeight();updateSend();
    toast('Отправлено на генерацию. Дождитесь результата.');
    try{N.generateMedia(mediaPending.id,JSON.stringify(payload));}
    catch(e){onMediaResult(mediaPending.id,JSON.stringify({ok:false,message:e.message}));}
  }
  function onMediaResult(requestId,output) {
    if(!mediaPending || mediaPending.id!==requestId) return;
    const request=mediaPending;mediaPending=null;
    let result;
    try{result=JSON.parse(output);}catch(e){result={ok:false,message:'Неверный ответ сервера'};}
    if(result.ok && result.uri){mediaHistory.unshift({id:request.id,kind:request.kind,prompt:request.prompt,uri:result.uri,created:Date.now()});saveGallery();renderGallery();toast('Готово! '+result.message);}
    else {toast('Ошибка: '+String(result.message||'Не удалось создать медиа').slice(0,320));$('messageInput').value=request.prompt;updateInputHeight();}
    updateSend();
  }
  function cancelMedia() {
    if(!mediaPending) return;
    if(N) N.cancelAI(mediaPending.id);
    mediaPending=null;toast('Генерация остановлена. Оплата уже начатого запроса возможна.');updateSend();
  }
  window.Vestnik = {onAIResult,onMediaResult,back};
  init();
})();
